<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
               Developed by <a href="{{ url('/') }}">Secure Me</a>
            </div>
        </div>
    </div>
</footer>
