<footer id="footer" class="footer">

    <div class="container pt-2">
      <div class="credits">
        Developed by <b><a href="{{ url('/') }}">Secure Me</a></b> 
      </div>
    </div>
  </footer>