
<?php $__env->startSection('content'); ?>
    <!-- ======= Services Section ======= -->
    <?php echo $__env->make('layouts.frontend.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Values Section -->
    
    <!-- ======= Counts Section ======= -->
    <?php echo $__env->make('layouts.frontend.counts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Counts Section -->
    
    <!-- ======= Team Section ======= -->
    <?php echo $__env->make('frontend.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Team Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Code\secure_me\resources\views/frontend.blade.php ENDPATH**/ ?>