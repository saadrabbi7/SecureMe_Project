<header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="<?php echo e(url('/')); ?>" class="logo d-flex align-items-center">
        <img src="<?php echo e(asset('')); ?>assets/frontend/img/logo.png" alt="">
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto <?php echo e((Request::segment(1) == null) ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
          <?php if(Request::segment(1) == null): ?>
            <li><a class="nav-link scrollto" href="#values">Services</a></li>
            <li><a class="nav-link scrollto" href="#team">Team</a></li>          
          <?php else: ?>
            <li><a class="nav-link scrollto" href="<?php echo e(url('/')); ?>">Services</a></li>
            <li><a class="nav-link scrollto" href="<?php echo e(url('/')); ?>">Team</a></li>
          <?php endif; ?>
          <li><a class="nav-link scrollto <?php echo e((Request::segment(1) == 'contact') ? 'active' : ''); ?>" href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
          <li><a class="nav-link scrollto <?php echo e((Request::segment(1) == 'law') ? 'active' : ''); ?>" href="<?php echo e(url('/law')); ?>">Law</a></li>
          <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('login')): ?>
              <li>
                <a class="nav-link " href="<?php echo e(url('/login')); ?>">Login</a>
              </li>
            <?php endif; ?>
            <?php if(Route::has('register')): ?>
              <li>
                  <a class="nav-link " href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
              </li>
            <?php endif; ?>
          <?php else: ?>
          
            <li>

                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <?php if(isset(auth()->user()->profile->picture)): ?>
                      <?php if(auth()->user()->profile->picture != null): ?>
                          <img src="<?php echo e(asset('profile-images/'.auth()->user()->profile->picture)); ?>" width="30px" height="30px" style="margin-right:5px; border-radius: 100%" />
                      <?php endif; ?>
                  <?php endif; ?>
                  <?php echo e(Auth::user()->name); ?>

                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <?php if(auth()->user()->is_admin == 1): ?>
                      <a href="<?php echo e(url('/dashboard')); ?>" class="dropdown-item">
                        <span style="margin-right:20px;"><i class="bi bi-gear" style="font-size: 17px; margin-left: -5px; "></i>  Control Panel</span>
                      </a>
                    <?php endif; ?>  
                    <a href="<?php echo e(url('/profile')); ?>" class="dropdown-item">
                      <span><i class="bi bi-person" style="font-size: 17px; margin-left: -5px;"></i>  Profile</span>
                    </a>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                      onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                        <span><i class="bi bi-box-arrow-right" style="font-size: 17px; margin-left: -5px;"></i> <?php echo e(__('Logout')); ?></span>
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
          <?php endif; ?> 
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><?php /**PATH D:\laragon\www\Code\secure_me\resources\views/layouts/frontend/nav.blade.php ENDPATH**/ ?>