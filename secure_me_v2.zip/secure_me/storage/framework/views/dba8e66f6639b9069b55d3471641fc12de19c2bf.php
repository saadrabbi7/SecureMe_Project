<footer id="footer" class="footer">

    <div class="container pt-2">
      <div class="credits">
        Developed by <b><a href="<?php echo e(url('/')); ?>">Secure Me</a></b> 
      </div>
    </div>
  </footer><?php /**PATH D:\laragon\www\Code\secure_me\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>