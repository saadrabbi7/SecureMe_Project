
<?php $__env->startSection('content'); ?>
    <section id="blog" class="blog mt-5">
        <div class="container" data-aos="fade-up">
            <header class="section-header">
                <p>Current Location</p>
            </header>
            <div class="row">
                <div class="col-md-12 entries">
                    <article class="entry entry-single">
                        <fieldset>
                            <legend>Location Status</legend>
                            <div class="row">
                                <?php if(isset($locationData) && $locationData != null): ?>
                                <div class="col-sm-2">
                                    <p><?php echo e(($locationData->countryName != null) ? "Country Name :" : ""); ?></p>
                                    <p><?php echo e(($locationData->regionName != null) ? "Division :" : ""); ?></p>
                                    <p><?php echo e(($locationData->cityName != null) ? "City Name :" : ""); ?></p>
                                </div>
                                <div class="col-sm-10">
                                    <p><strong><?php echo e(($locationData->countryName != null) ? $locationData->countryName : ""); ?></strong></p>
                                    <p><strong><?php echo e(($locationData->regionName != null) ? $locationData->regionName : ""); ?></strong></p>
                                    <p><strong><?php echo e(($locationData->cityName != null) ? $locationData->cityName : ""); ?></strong></p>
                                </div>
                                <?php else: ?>
                                    <small class="text-secondary">IP Address Not Found</small>
                                <?php endif; ?>
                            </div>
                        </fieldset>
                    </article>
                    <div id="map" class="img-thumbnail shadow-lg p-3 mb-5 bg-white rounded"></div>
                </div><!-- End blog entries list -->
            </div>
        </div>
    </section>
    <?php $__env->startPush('css'); ?>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
        <style>
            #map {
                width: 100%;
                height: 80vh;
            }
        </style>
    <?php $__env->stopPush(); ?>
    <?php $__env->startPush('js'); ?>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
            navigator.geolocation.getCurrentPosition(function(location) {
                console.log(location.coords.latitude, location.coords.longitude, location.coords.accuracy);
                var latlng = new L.LatLng(location.coords.latitude, location.coords.longitude);
                var accuracy = location.coords.accuracy;

                var map = L.map('map').setView(latlng, 15);
                L.tileLayer('https://api.maptiler.com/maps/streets/{z}/{x}/{y}.png?key=ha32QM3NC5s4H3Xyq5hJ', {
                    attribution : '<a href="https://www.maptiler.com/copyright/" target="_blank">&copy; MapTiler</a> <a href="https://www.openstreetmap.org/copyright" target="_blank">&copy; OpenStreetMap contributors</a>',
                }).addTo(map);

                var marker = L.marker(latlng).addTo(map);
                var circle = L.circle(latlng, {radius: accuracy});

                var featureGroup = L.featureGroup([marker, circle]).addTo(map);

            });
    
    </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Code\secure_me\resources\views/frontend/services/location.blade.php ENDPATH**/ ?>