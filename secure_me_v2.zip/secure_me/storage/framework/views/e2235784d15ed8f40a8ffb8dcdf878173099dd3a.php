<section id="hero" class="hero d-flex align-items-center">

    <div class="container">
        <div class="row">
            <div class="col-lg-6 d-flex flex-column justify-content-center">
                <h1 data-aos="fade-up">Secure Me</h1>
                <h2 data-aos="fade-up" data-aos-delay="400">Click the button for emergancy alert</h2>
                <div data-aos="fade-up" data-aos-delay="600">
                    <div class="text-center text-lg-start">
                        <form action="<?php echo e(route('emergency-alert')); ?>" method="post"><?php echo csrf_field(); ?>
                            <?php if(!isset(auth()->user()->profile->f_mobile_no)): ?>
                              <input type="number" class="form-control my-1 w-50" name="relative_phone" id="phone_number" placeholder="Relatives Phone Number" value="8801" />
                            <?php else: ?>
                              <input type="hidden" class="form-control my-1 w-50" name="relative_phone" value="88<?php echo e(auth()->user()->profile->f_mobile_no); ?>" />
                              <input type="hidden" name="police_station" value="<?php echo e(isset(auth()->user()->profile->police_station_id) ? auth()->user()->profile->police_station_id : null); ?>">
                            <?php endif; ?>
                            <input type="hidden" name="url" id="url">
                            <button type="submit" id="emergencyAlert"  class="btn btn-danger mt-2 scrollto d-inline-flex align-items-center justify-content-center align-self-center">
                                <i class="far fa-bell"></i>
                                <span> &nbsp; Emergency Alert</span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 hero-img" data-aos="zoom-out" data-aos-delay="200">
                <img src="<?php echo e(asset('')); ?>assets/frontend/img/hero-img.png" class="img-fluid" alt="">
            </div>
        </div>
    </div>
    
</section>
<?php $__env->startPush('js'); ?>
    <script>
        navigator.geolocation.getCurrentPosition(function(location) {
            let latitude = location.coords.latitude;
            let longitude = location.coords.longitude;
            let accuracy = location.coords.accuracy;

            // let url =  'https://secureme/locations/' + latitude + '/' + longitude+ '/' + accuracy ;
            // let text = "Location";
            // let result = text.link(`https://);
            let result = `www.secureme.pm-devs.xyz/locations/${latitude}/${longitude}/${accuracy}`;

            $('#url').val(result);

        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH D:\laragon\www\Code\secure_me\resources\views/layouts/frontend/emergency.blade.php ENDPATH**/ ?>